"""
News Pipeline package.
An intelligent AI pipeline that processes RSS feeds into prediction market questions.
"""

__version__ = "0.1.0"
